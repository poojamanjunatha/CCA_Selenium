import org.openqa.selenium.WebDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;

public class Registration 
{
	static WebDriver driver;
	static String baseUrl; 
	
	public WebDriver setupDriver()
	{
	    DriverSetup setup = new DriverSetup();
	    driver = setup.getWebDriver();
	    baseUrl = "http://webapps.tekstac.com/Shopify/";
	    driver.get(baseUrl);
	    //Assign the value for baseUrl
	    /* Get the driver, and launch the app using get() with baseUrl */
	     return driver;
	}
	
	public void setElements()
	{
	    driver.findElement(By.id("firstname")).sendKeys("Mithali");
	    driver.findElement(By.id("lastname")).sendKeys("Raj");
	    driver.findElement(By.id("username")).sendKeys("Mithali Raj");
	    Select select = new Select(driver.findElement(By.id("selectcity")));
	    select.selectByVisibleText("Chennai");
	    driver.findElement(By.xpath("//input[@value='female']")).click();
	    driver.findElement(By.id("pass")).sendKeys("MR@123");
	    driver.findElement(By.id("reg")).click();
	    /*Using the driver, Find the elements by id and send the values to the elements*/
 	}
	
	public static void main(String[] args)
	{
	    Registration reg=new Registration();
	    reg.setupDriver();
	    reg.setElements();
	}
}