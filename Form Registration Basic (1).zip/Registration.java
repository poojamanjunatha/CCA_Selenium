import org.openqa.selenium.WebDriver;
import org.openqa.selenium.By;

public class Registration 
{
	String fName;
	static WebDriver driver;
	static String baseUrl; 
	
public WebDriver setupDriver()
	{
	    DriverSetup setup = new DriverSetup();
	    driver = setup.getWebDriver();
	    baseUrl = "http://webapps.tekstac.com/Shopify/";
	    driver.get(baseUrl);
	    /* Invoke the getWebDriver method 
	       Set value of BaseUrl
	       Launch the app using get() with baseUrl */
	     return driver;
	}
	
	public void setElements()
	{
	    driver.findElement(By.id("firstname")).sendKeys("Rahul");
	    driver.findElement(By.id("lastname")).sendKeys("Dravid");
	    driver.findElement(By.id("username")).sendKeys("Rahul Dravid");
	    driver.findElement(By.id("pass")).sendKeys("gentlemancrickter");
	    driver.findElement(By.id("reg")).click();
	    /*Using the driver, Find the elements by id 
	      Set the values to the elements
	      Register the form*/
	}
	
	public static void main(String[] args)
	{
	    Registration reg=new Registration();
	    reg.setupDriver();
	    reg.setElements();
	}
}