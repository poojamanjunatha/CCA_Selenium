import org.openqa.selenium.WebDriver;
import org.openqa.selenium.By;

public class NameLocator 
{
	String fName = "";  
	static WebDriver driver;  
	
	public WebDriver setupDriver()
	{
	    DriverSetup setupDriver = new DriverSetup();
	    driver = setupDriver.getWebDriver();
	    /*Invoke the getWebDriver method from the DriverSetup File*/
	    return driver;
	}
	public String getNameLocator()
	{
       /*Identify the Firstname
	     Get the placeholder value
         Store the placeholder value in the static variable fName.*/
         setupDriver();
         fName = driver.findElement(By.name("fname")).getAttribute("placeholder");
       return fName;
	}
	
	public static void main(String[] args)
	{
	    NameLocator namLocator=new NameLocator();
	    String name=namLocator.getNameLocator();
	    System.out.println("The name is "+name);
	}
}