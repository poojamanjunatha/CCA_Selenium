import org.openqa.selenium.WebDriver;
import org.openqa.selenium.By;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.File;
import java.io.IOException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;
public class NameLocator   //DO NOT Change the class Name
{
public static WebDriver driver;
public static XPath xpath;
public static Document doc;
public static DocumentBuilder dBuilder;
public WebDriver createDriver() //DO NOT change the method signature
{
  //Implement code to create Driver from DriverSetup, set to 'static' driver variable and return it
  DriverSetup d=new DriverSetup();
  driver=d.getWebDriver();
  return driver;
}
public XPath ReadFile(String xmlfileName,String id)throws XPathExpressionException, SAXException, Exception   //DO NOT change the method signature
    {
        //Implement code to read and assign the XPath object reference to xpath static variable
             File XmlFile = new File(xmlfileName);
                DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
                dBuilder = dbFactory.newDocumentBuilder();
                 doc = dBuilder.parse(XmlFile);
                 xpath =  XPathFactory.newInstance().newXPath();
                 return xpath;
   }
    public  String getFirstName(int id)throws Exception {
        //Implement code to return firstname from xml
          String expression = String.format("/UserDetails/User[@id='"+id+"']/Firstname");
        Node node = (Node) xpath.compile(expression).evaluate(doc, XPathConstants.NODE);
        String firstname = node.getTextContent();
        return firstname;
   }
    public  String getLastName(int id)throws Exception {
        //Implement code to return lastname from xml
         String expression = String.format("/UserDetails/User[@id='"+id+"']/Lastname");
        Node node = (Node) xpath.compile(expression).evaluate(doc, XPathConstants.NODE);
       String lastname = node.getTextContent();
       return lastname;
    }
    public  String getUserName(int id)throws Exception {
        //Implement code to return username from xml
           String expression = String.format("/UserDetails/User[@id='"+id+"']/Username");
        Node node = (Node) xpath.compile(expression).evaluate(doc, XPathConstants.NODE);
        String username = node.getTextContent();
         return username;
   }
    public  String getPassword(int id)throws Exception{
        //Implement code to return passworf from xml
          String expression = String.format("/UserDetails/User[@id='"+id+"']/Password");
        Node node = (Node) xpath.compile(expression).evaluate(doc, XPathConstants.NODE);
        String password = node.getTextContent();
         return password;
    }
      public  String  getMessage()throws  Exception{  
        //Implement code to submit form with values got from xml and return the success message printed on the page.
        String f=getFirstName(1);
        String l=getLastName(1);
        String u=getUserName(1);
        String p=getPassword(1);
        driver.findElement(By.id("firstname")).sendKeys(f);
        driver.findElement(By.id("lastname")).sendKeys(l);
        driver.findElement(By.id("username")).sendKeys(u);
        driver.findElement(By.id("pass")).sendKeys(p);
        driver.findElement(By.id("reg")).click();
        return "Registered Successfully";
    }
public static void main(String[] args) throws Exception
{
      NameLocator pagLocator=new NameLocator();
   pagLocator.ReadFile(System.getProperty("user.dir")+"/Userdetails.xml","1");
   pagLocator.getMessage();
   driver.close();
  //Implement the required code
   //Close the driver
}
}
