import org.openqa.selenium.WebDriver;
import org.openqa.selenium.By;
import java.io.FileReader;
import java.util.Iterator;
import java.util.Map;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
public class NameLocator //DO NOT Change the class Name
{
	JSONArray address;
	public static WebDriver driver;
	public static JSONArray agent;
	public static JSONObject jsonObject;
	public static JSONParser parser;
	public static Object obj;
	public static JSONObject o;
	String FirstName;
	String LastName;
	String UserName;
	String Password;
	String PhoneNumber;
	String Email ;
 public void createDriver() //DO NOT change the method signature
	{
	     driver= DriverSetup.getWebDriver();
	   //Implement code to create Driver from DriverSetup and set to 'static' driver variable
	}
	
	public JSONArray ReadFile(String fileName)  throws Exception //DO NOT change the method signature
    {
        //Implement code to read and return agents as JSON array 
        JSONParser parser= new JSONParser();
    obj= parser.parse(new FileReader(fileName));
      jsonObject =(JSONObject)obj;
        agent=(JSONArray)jsonObject.get("Agents");
        System.out.println(agent.size());
return agent;  
    }
    public String getFirstName(int id) {
		//Implement code to return firstname from agent
		o=(JSONObject)agent.get(id-1);
        String ID=""+id+"";
        FirstName =(String)o.get("FirstName");
        System.out.println("nickname" + FirstName);
        return FirstName;
	}

	public String getLastName(int id) {
		//Implement code to return lastname from agent
			o=(JSONObject)agent.get(id-1);
        String ID=""+id+"";
        LastName =(String)o.get("LastName");
        System.out.println("LastName" + LastName);
        return LastName;
	}

	public String getUserName(int id) {
	//Implement code to return username from agent
	o=(JSONObject)agent.get(id-1);
        String ID=""+id+"";
        UserName =(String)o.get("UserName");
        System.out.println("UserName" + UserName);
        return UserName;
	}

	public String getPhoneNumber(int id) {
		//Implement code to return phonenumber from agent
		o=(JSONObject)agent.get(id-1);
        String ID=""+id+"";
        PhoneNumber =(String)o.get("PhoneNumber");
        System.out.println("PhoneNumber" + PhoneNumber);
        return PhoneNumber;
	}
	
	public String getPassword(int id) {
		//Implement code to return password from agent
			o=(JSONObject)agent.get(id-1);
        String ID=""+id+"";
        Password =(String)o.get("Password");
        System.out.println("Password" + Password);
        return Password;
	}
	public String getEmail(int id) {
		//Implement code to return email from agent
			o=(JSONObject)agent.get(id-1);
        String ID=""+id+"";
        Email =(String)o.get("Email");
        System.out.println("Email" + Email);
        return Email;
	}
	public String getMessage() {
		//Implement code to submit form with values got from json and return the success message printed on the page.
driver.findElement(By.name("firstname")).sendKeys(FirstName);
			driver.findElement(By.name("lastname")).sendKeys(LastName);
				driver.findElement(By.name("username")).sendKeys(UserName);
					driver.findElement(By.name("password")).sendKeys(PhoneNumber);
						driver.findElement(By.name("phonenumber")).sendKeys(Password);
						driver.findElement(By.name("email")).sendKeys(Email);
						return "Registered successfully";
	}

	public static void main(String[] args) throws Exception{
		NameLocator nameLocator = new NameLocator();
		//Implement the required code
	    //Close the driver
	    String path=System.getProperty("user.dir")+"/AgentDetail.json";
	    nameLocator.createDriver();
	    nameLocator.ReadFile(path);
	    for(int i=1;i<agent.size();i++)
{
    nameLocator.getFirstName(i);
    nameLocator.getLastName(i);
   nameLocator.getUserName(i);
   nameLocator.getPhoneNumber(i);
    nameLocator.getPassword(i);
    nameLocator.getEmail(i);
    nameLocator.getMessage();
   }
    driver.close();
}
}
