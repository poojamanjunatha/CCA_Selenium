import org.openqa.selenium.WebDriver;
import org.openqa.selenium.By;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.File;
import java.io.IOException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;
public class FieldLocator {  //DO NOT Change the class Name
  public static WebDriver driver;
	public static XPath xpath;
public static Document doc;
  public static DocumentBuilder dBuilder;
	public WebDriver createDriver() //DO NOT change the method signature
	{
	   //Implement code to create Driver from DriverSetup, set to 'static' driver variable and return it
	   DriverSetup d=new DriverSetup();
  driver=d.getWebDriver();
  return driver;
	}
public XPath ReadFile(String xmlfileName,String id)  throws XPathExpressionException, SAXException, Exception  //DO NOT change the method signature
    {
        //Implement code to read and return XPath object reference
        File XmlFile = new File(xmlfileName);
                DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
                dBuilder = dbFactory.newDocumentBuilder();
                 doc = dBuilder.parse(XmlFile);
                 xpath =  XPathFactory.newInstance().newXPath();
                  return xpath;
    }	
	public  String getCustomerName(int id) throws Exception{
        //Implement code to return customername from xml  
         String expression = String.format("/CustomerDetails/Customer[@id='"+id+"']/Customername");
        Node node = (Node) xpath.compile(expression).evaluate(doc, XPathConstants.NODE);
        String Customername = node.getTextContent();
        return Customername;
    }
    public  String getInvoiceNumber(int id) throws Exception{
       //Implement code to return invoicenumber from xml   
       String expression = String.format("/CustomerDetails/Customer[@id='"+id+"']/Invoicenumber");
        Node node = (Node) xpath.compile(expression).evaluate(doc, XPathConstants.NODE);
        String Invoicenumber = node.getTextContent();
        return Invoicenumber;
    }
    public  String getAmount(int id) throws Exception{
        //Implement code to return amount from xml 
        String expression = String.format("/CustomerDetails/Customer[@id='"+id+"']/Amount");
        Node node = (Node) xpath.compile(expression).evaluate(doc, XPathConstants.NODE);
        String Amount = node.getTextContent();
        return Amount;
    }
   public  String getMobileNumber(int id) throws Exception{
        //Implement code to return phone number from xml   
        String expression = String.format("/CustomerDetails/Customer[@id='"+id+"']/Mobilenumber");
        Node node = (Node) xpath.compile(expression).evaluate(doc, XPathConstants.NODE);
        String Mobilenumber = node.getTextContent();
        return Mobilenumber;
    }
     public  String  getMessage() throws Exception{  
        //Implement code to submit form with values got from xml and return the success message printed on the page.
          String c=getCustomerName(1);
        String l=getInvoiceNumber(1);
        String a=getAmount(1);
        String m=getMobileNumber(1);
        driver.findElement(By.id("name")).sendKeys(c);
        driver.findElement(By.id("number")).sendKeys(l);
        driver.findElement(By.name("amount")).sendKeys(a);
        driver.findElement(By.name("num")).sendKeys(m);
        driver.findElement(By.id("submit")).click();
       return "Registered Successfully";
      }
     public static void main(String[] args) throws Exception
	{
	    FieldLocator pagLocator=new FieldLocator();
	   //Implement the required code
	    //Close the driver
	     pagLocator.ReadFile(System.getProperty("user.dir")+"/CustomerDetails.xml","1");
   pagLocator.getMessage();
   driver.close();
	} 
}
