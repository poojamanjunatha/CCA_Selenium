import org.openqa.selenium.WebDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class NameLocator {      //DO NOT change the class name
 
    public static String baseUrl; //Assign 'http://webapps.tekstac.com/Handling_Regular_Expression/' for baseUrl
    public static WebDriver driver;
	
	public WebDriver createDriver()
	{
	    //Create driver. Assign it to static variable 'driver' and return it
	     driver=DriverSetup.getWebDriver();
		return driver;
	}
	
	public void navigate(WebDriver driver){
	     //Navigate to the baseUrl
	     baseUrl="http://webapps.tekstac.com/Handling_Regular_Expression/";
	     driver.get(baseUrl);
	     
	}
	
   public void setFormValues(WebDriver driver)
		{
		    //set the value for 'Shipment for user' and submit form
			driver.findElement(By.cssSelector("#userId")).sendKeys("Shamili");
		driver.findElement(By.cssSelector("#track")).click();	
		}

	    public WebElement getNameResultElement(WebDriver driver) {
	        //Find the element of 'Shamili' and return it
	      WebElement name=  driver.findElement(By.xpath("//td[contains(text(),'Shamili')]"));
	      return name;
	    }
	    public WebElement getShipmentResultElement(WebDriver driver) {
	         //Find the element of 'SHIP1236' and return it
	    	 WebElement shipment=  driver.findElement(By.xpath("//div[@id='shipment']"));
		      return shipment;
	    }
	    public WebElement getEmailResultElement(WebDriver driver) {
	        
	        //Find the element of 'shamili93@gamil.com' and return it
	    	 WebElement email=  driver.findElement(By.xpath("//div[@id='e- mail']"));
		      return email;
	    }
	    
	    public boolean validateEmail(String eMailID) {
	       //Validate email using regex. 
	    	String regex="\\b[A-Z0-9a-z-]+@[a-z]+\\.[a-z]{2,4}\\b";
	    	return eMailID.matches(regex);
	    	
	    }
	    public boolean validateShipmentId(String shipmentId) {
	        //Validate shipmentId using regex
	    	String reg="[A-Z0-9]{8}";
	    	return shipmentId.matches(reg);
	        
	    }    
  
    public static void main(String[] args)
	{
	    NameLocator reg=new NameLocator();
	     //Add required code here
	      WebDriver driver = reg.createDriver();
	      reg.navigate(driver);
		reg.setFormValues(driver);
	reg.getShipmentResultElement(driver);
    
	
	reg.getEmailResultElement(driver);
	System.out.println(reg.validateEmail("shamili93@gamil.com"));
		
		 System.out.println(reg.validateShipmentId("SHIP1236"));
	}

  
}