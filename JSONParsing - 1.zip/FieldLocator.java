import org.openqa.selenium.WebDriver;
import org.openqa.selenium.By;
import java.io.FileReader;
import java.util.Iterator;
import java.util.Map;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
public class FieldLocator //DO NOT Change the class Name
{
	JSONArray address;
	public static WebDriver driver;
	public static JSONArray addressBook;
	public static JSONObject jsonObject;
	public static JSONParser parser;
	public static Object obj;
	public static JSONObject o;
	String nickName;
	String ContactName;
	String city;
	String type;
 public void createDriver() //DO NOT change the method signature
	{
	   //Implement code to create Driver from DriverSetup and set to 'static' driver variable
	  driver= DriverSetup.getWebDriver();
	}
	
	public JSONArray ReadFile(String fileName)  throws Exception //DO NOT change the method signature
    {
        //Implement code to read and return addresses as JSON array 
        JSONParser parser= new JSONParser();
    obj= parser.parse(new FileReader(fileName));
      jsonObject =(JSONObject)obj;
        addressBook=(JSONArray)jsonObject.get("Addresses");
        System.out.println(addressBook.size());
return addressBook;        
   }
    public String getNickName(int id) {
	  //Implement code to return nickname from address
     o=(JSONObject)addressBook.get(id-1);
        String ID=""+id+"";
        nickName =(String)o.get("NickName");
        System.out.println("nickname" + nickName);
        return nickName;
    }

	public String getContactName(int id) {
		//Implement code to return contactname from address
		o=(JSONObject)addressBook.get(id-1);
        String ID=""+id+"";
    ContactName =(String)o.get("ContactName");
        System.out.println("contactName" + ContactName);
        return ContactName;
	}

	public String getCity(int id) {
		//Implement code to return city from address
			o=(JSONObject)addressBook.get(id-1);
        String ID=""+id+"";
    city =(String)o.get("City");
        System.out.println("city" + city);
        return city;
	}

	public String getType(int id) {
		//Implement code to return type from address
			o=(JSONObject)addressBook.get(id-1);
        String ID= ""+id+"";
    type =(String)o.get("Type");
        System.out.println("Type" + type);
        return type;
	}

	public String getMessage() {
		//Implement code to submit form with values got from json and return the success message printed on the page.
		driver.findElement(By.id("nickname")).sendKeys(nickName);
			driver.findElement(By.id("contact")).sendKeys(ContactName);
				driver.findElement(By.id("city")).sendKeys(city);
					driver.findElement(By.id("type")).sendKeys(type);
						driver.findElement(By.id("add")).click();
						return "Registered successfully";
	}

	public static void main(String[] args) throws Exception{
		FieldLocator pagLocator=new FieldLocator();
	   //Implement the required code
	    //Close the driver
	    String path=System.getProperty("user.dir")+"/AddressBook.json";
	    pagLocator.createDriver();
	    pagLocator.ReadFile(path);
	    for(int i=1;i<addressBook.size();i++)
{
    pagLocator.getNickName(i);
    pagLocator.getContactName(i);
    pagLocator.getCity(i);
    pagLocator.getType(i);
    pagLocator.getMessage();
    
    }
    driver.close();
}
}
