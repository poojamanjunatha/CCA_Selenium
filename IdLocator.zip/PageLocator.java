import org.openqa.selenium.WebDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class PageLocator    //DO NOT Change the class Name
{
    static String lName;
    static WebDriver driver;
	
	public WebDriver createDriver()  //DO NOT change the method signature
	{
	   DriverSetup setup = new DriverSetup();
	   driver = setup.getWebDriver(); 
	   //Invoke getWebDriver method from DriverSetup and return it
	   return driver;
	}
	
	public WebElement getPageLocator(WebDriver driver)  //DO NOT change the method signature
	{
	    WebElement element = driver.findElement(By.id("lastname"));
	    return element;
	   /*Replace this comment by the code statement to get the WebElement of 'Lastname'*/
	   /*Find the element by id */
	   
	}
	public String getName(WebElement element)  //DO NOT change the method signature
	{
	    lName = element.getAttribute("placeholder");
	    System.out.println("The name is"+lName);
	    return lName;
	    //Get the attribute value from the element and return it
	}
	
	public static void main(String[] args){
	    PageLocator pl=new PageLocator();
	    pl.createDriver();
	    WebElement ele = pl.getPageLocator(driver);
	    pl.getName(ele);
	    //Add required code
	}
}