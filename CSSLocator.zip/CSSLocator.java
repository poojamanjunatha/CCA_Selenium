import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
public class CSSLocator     //DO NOT change the class name
{
	public WebDriver createDriver()  //DO NOT change the method signature
	{
	   //Implement code to create Driver from DriverSetup and return it
	   
	  WebDriver driver= DriverSetup.getWebDriver();
	  return driver;
	}
	
	public WebElement getCSSLocator(WebDriver driver)  //DO NOT change the method signature
	{
	   /*Replace this comment by the code statement to get the Web element of username*/
	   /*Find and return the element */ 
	 WebElement element=    driver.findElement(By.cssSelector("#username"));
	 return element;
       
	}
	
	public String getName(WebElement element)  //DO NOT change the method signature
	{
	    //Get the attribute value from the element and return it
	    String name=element.getAttribute("placeholder");
	    return name;
	}
	
    public static void main(String[] args){
	    CSSLocator pl=new CSSLocator();
	    //Add required code
	  WebDriver driver=  pl.createDriver();
	  WebElement element=  pl.getCSSLocator(driver);
	 System.out.println(pl.getName(element));
	}
}