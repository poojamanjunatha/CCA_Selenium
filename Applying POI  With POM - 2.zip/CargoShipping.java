import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.ss.usermodel.*;

public class CargoShipping   //DO NOT change the class name
{
public static XSSFSheet sheet;
public static File file;
public static FileInputStream fis;
public static FileOutputStream fos;

public static XSSFWorkbook wb;
public static Row row;
public static Cell cell;
   
    public static void writeExcelData(String fileName,String result) throws Exception { //Do not change the method signature
        //Write the Test result to the excel sheet
    file= new File(fileName);
   
    fis= new FileInputStream(file);
    wb= new XSSFWorkbook(fis);
    sheet= wb.getSheet("TestCase");
   
    row= sheet.createRow(0);
    cell= row.createCell(0);
    cell.setCellValue(result);
    fos= new FileOutputStream(file);
    wb.write(fos);
    fos.close(); 
    }
   
}
